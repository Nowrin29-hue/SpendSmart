import { getAllExpenses, addExpense, deleteExpense } from "../models/expensesModel.js";


export const fetchExpenses = async (req, res, next) => {
try {
const expenses = await getAllExpenses();
res.json(expenses);
} catch (err) {
next(err);
}
};


export const createExpense = async (req, res, next) => {
try {
const expense = await addExpense(req.body);
res.status(201).json(expense);
} catch (err) {
next(err);
}
};


export const removeExpense = async (req, res, next) => {
try {
const deleted = await deleteExpense(req.params.id);
if (!deleted) return res.status(404).json({ message: "Expense not found" });
res.json(deleted);
} catch (err) {
next(err);
}
};